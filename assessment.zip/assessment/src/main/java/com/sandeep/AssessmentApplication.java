package com.sandeep;

import com.github.javafaker.Faker;
import com.sandeep.model.User;
import com.sandeep.repository.UserRepository;
import com.sandeep.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@SpringBootApplication
@RestController
public class AssessmentApplication {

	private final Faker faker = new Faker();

	@RequestMapping("/")
	public String home() {
		return "Hello World! The Application is working!!!";
	}

	@Bean
	public CommandLineRunner initializeDb(UserService userService) {
		return (args) -> {
			userService.deleteAllUsers();
			userService.save(new User("sandeep", "sandeep@gmail.com", faker.internet().password(), LocalDateTime.now()));
			for (int i = 0; i < 10; i++) {
				userService.save(new User(faker.name().firstName(), faker.internet().emailAddress(), faker.internet().password(), LocalDateTime.now()));
			}
		};
	}

	public static void main(String[] args) {
		SpringApplication.run(AssessmentApplication.class, args);
	}
}
