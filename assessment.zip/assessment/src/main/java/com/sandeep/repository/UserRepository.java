package com.sandeep.repository;

import com.sandeep.model.User;

import java.util.List;

public interface UserRepository {
  List<User> getUsers();
  User save(User user);
  void deleteAll();
}
