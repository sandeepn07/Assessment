package com.sandeep.repository;

import com.sandeep.model.User;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class UserRepositoryImpl implements UserRepository {

  private List<User> users = new ArrayList<>();

  @Override
  public List<User> getUsers() {
    return users;
  }

  @Override
  public User save(User user) {
    users.add(user);
    return user;
  }

  @Override
  public void deleteAll() {
    users.clear();
  }
}
