package com.sandeep.controller;

import com.sandeep.model.User;
import com.sandeep.repository.UserRepository;
import com.sandeep.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/users")
public class UserController {

  @Autowired
  private UserService userService;

  @RequestMapping(method = RequestMethod.GET)
  public ResponseEntity<List<User>> getAllUsers() {
    return new ResponseEntity<>(userService.getUsers(), HttpStatus.OK);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/{username}")
  public ResponseEntity<User> getUserByUsername(@PathVariable final String username) {
    return new ResponseEntity<>(userService.getUserByUsername(username), HttpStatus.OK);
  }

  @RequestMapping(method = RequestMethod.GET, params = {"email"})
  public ResponseEntity<User> getUserByEmail(@RequestParam(value = "email") final String email) {
    return new ResponseEntity<>(userService.getUsersByEmail(email), HttpStatus.OK);
  }

  @ExceptionHandler(value = NoSuchElementException.class)
  public String elementNotFoundException() {
    return "User Not Found";
  }
}
