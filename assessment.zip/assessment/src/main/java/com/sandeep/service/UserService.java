package com.sandeep.service;

import com.sandeep.model.User;

import java.util.List;

public interface UserService {
  User save(User user);
  void deleteAllUsers();
  List<User> getUsers();
  User getUserByUsername(String userName);

  default User getUsersByEmail(String email) {
    List<User> users = getUsers();
    return users.stream().filter(user -> user.getEmail().equals(email)).findFirst().get();
  }
}
